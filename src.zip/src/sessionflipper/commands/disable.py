from __future__ import annotations

from sessionflipper.config import (
    load_config,
    save_config,
    set_automatic_switching,
)


def run() -> int:
    config = load_config()

    save_config(
        set_automatic_switching(
            config,
            False,
        )
    )

    return 0
