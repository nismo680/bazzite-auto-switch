"""
Functions for discovering DRM devices.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

from sessionflipper.drm_parser import parse_connector_name
from sessionflipper.edid import parse_edid
from sessionflipper.models import GPU, Connector

DRM_PATH = Path("/sys/class/drm")

_STATUS_MAP: dict[str, bool | None] = {
    "connected": True,
    "disconnected": False,
    "unknown": None,
}

_ENABLED_MAP: dict[str, bool | None] = {
    "enabled": True,
    "disabled": False,
}


def find_drm_cards(base_path: Path = DRM_PATH) -> tuple[Path, ...]:
    """
    Return all DRM card directories.
    """
    if not base_path.exists():
        return ()

    return tuple(
        sorted(
            entry
            for entry in base_path.iterdir()
            if entry.is_dir() and entry.name.startswith("card") and "-" not in entry.name
        )
    )


def find_connectors(card: Path) -> tuple[Path, ...]:
    """
    Return all connector directories belonging to a DRM card.
    """
    drm_path = card.parent
    prefix = f"{card.name}-"

    return tuple(
        sorted(
            entry
            for entry in drm_path.iterdir()
            if entry.is_dir() and entry.name.startswith(prefix)
        )
    )


def read_text(path: Path, filename: str) -> str | None:
    """
    Read a text file below *path*.

    Returns None if the file does not exist or cannot be read.
    """
    try:
        return (path / filename).read_text(encoding="utf-8").strip()
    except OSError:
        return None


def _read_mapped_value(
    path: Path,
    filename: str,
    mapping: dict[str, bool | None],
) -> bool | None:
    """
    Read a sysfs attribute and map its value.
    """
    value = read_text(path, filename)

    if value is None:
        return None

    return mapping.get(value)


def read_status(connector: Path) -> bool | None:
    """
    Return the connector status.
    """
    return _read_mapped_value(connector, "status", _STATUS_MAP)


def read_enabled(connector: Path) -> bool | None:
    """
    Return whether the connector is enabled.
    """
    return _read_mapped_value(connector, "enabled", _ENABLED_MAP)


def read_connector(path: Path) -> Connector:
    """
    Read a DRM connector.
    """
    connector_type, number = parse_connector_name(path.name)

    manufacturer = None
    monitor_name = None
    display_fingerprint = None

    edid = read_edid(path)
    if edid is not None:
        display_fingerprint = get_display_fingerprint(edid)

        try:
            info = parse_edid(edid)
        except ValueError:
            pass
        else:
            manufacturer = info.manufacturer
            monitor_name = info.monitor_name

    return Connector(
        drm_id=path.name,
        connector_type=connector_type,
        number=number,
        connected=read_status(path),
        enabled=read_enabled(path),
        display_fingerprint=display_fingerprint,
        manufacturer=manufacturer,
        monitor_name=monitor_name,
    )


def read_gpu(card: Path) -> GPU:
    """
    Read a DRM GPU and all of its connectors.
    """
    return GPU(
        drm_id=card.name,
        name=card.name,
        connectors=tuple(read_connector(connector) for connector in find_connectors(card)),
    )


def read_gpus(base_path: Path = DRM_PATH) -> tuple[GPU, ...]:
    """
    Read all DRM GPUs.
    """
    return tuple(read_gpu(card) for card in find_drm_cards(base_path))


def read_edid(connector: Path) -> bytes | None:
    """
    Read the EDID of a connector.

    Returns None if no valid EDID is available.
    """
    try:
        edid = (connector / "edid").read_bytes()
    except OSError:
        return None

    if len(edid) < 128:
        return None

    return edid


def get_display_fingerprint(edid: bytes | None) -> str | None:
    if edid is None:
        return None

    return hashlib.sha256(edid).hexdigest()[:12]
